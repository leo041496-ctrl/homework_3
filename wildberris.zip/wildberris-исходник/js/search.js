const search = () => {
    const input = document.querySelector(".search-block > input")
    const searchBtn = document.querySelector(".search-block > button")

    // input.addEventListener('input', (event) =>{
    //     console.log(event.target.value);
    // } )

    // try{ searchBtn.addEventListener('click', () => {console.log(input.value); })}
    // catch(e){
    //     console.log(e);
    // }

    const renderGoods = (goods) => {
        const goodContainer = document.querySelector('.long-goods-list')
        goodContainer.innerHTML ="" 
        goods.forEach((good) => {
            const goodBlock = document.createElement('div')
            console.log(good);
            goodBlock.classList.add('col-lg-3')
            goodBlock.classList.add('col-sm-6')

            goodBlock.innerHTML = `
            <div class="goods-card">
					<span class="label ${good.label ? null : 'd-none'}">${good.label}</span>
					<img src="db/${good.img}" alt="${good.name}" class="goods-image">
					<h3 class="goods-title">${good.name}</h3>
					<p class="goods-description">${good.description}</p>
					<button class="button goods-card-btn add-to-cart" data-id="${good.id}">
						<span class="button-price">$${good.price}</span>
					</button>
			</div> `

            goodContainer.append(goodBlock) 
            console.log(goodBlock); })

    }

    const GetData = (value) => {
        fetch('https://test-6feb2-default-rtdb.asia-southeast1.firebasedatabase.app/db.json').then((res) => res.json()
        ).then((data) => {
            const array = data.filter(good => good.name.toLowerCase().includes(value.toLowerCase()))//includes спрашивает есть ли строка value внутри строки good. "куртка зимняя".includes("курт")
            localStorage.setItem('goods', JSON.stringify(array))
            if (window.location.pathname !== '/goods.html') {
                window.location.href = '/goods.html' 
            } else { renderGoods(array) }

        })
    }
    searchBtn.addEventListener('click', () => {
        console.log(input.value)
        GetData(input.value)
    })

    
}

search()