const GetGoods = () => {
    const links = document.querySelectorAll('.navigation-link')
    const Viewall = document.querySelector('.more')

    const renderGoods = (goods) => {
        const goodContainer = document.querySelector('.long-goods-list')
        goodContainer.innerHTML ="" //чистим контейнер чтобы при новом запросе старое очищалось, а не накладывалось друг на друга

        goods.forEach((good) => {
            const goodBlock = document.createElement('div')
            console.log(good);
            goodBlock.classList.add('col-lg-3')
            goodBlock.classList.add('col-sm-6')

            goodBlock.innerHTML = `
            <div class="goods-card">
					<span class="label ${good.label ? null : 'd-none'}">${good.label}</span>
					<img src="db/${good.img}" alt="${good.name}" class="goods-image">
					<h3 class="goods-title">${good.name}</h3>
					<p class="goods-description">${good.description}</p>
					<button class="button goods-card-btn add-to-cart" data-id="${good.id}">
						<span class="button-price">$${good.price}</span>
					</button>
			</div>
            `
            goodContainer.append(goodBlock) //при каждом выполнении цикла блок будет добавляться в конец контейнера
            console.log(goodBlock);
            //Свойство innerHTML добавляется для того, чтобы одним махом наполнить пустой контейнер goodBlock
            // полноценной HTML-структурой карточки товара 
        })

    }

    const GetData = (category, value) => {
        fetch('https://test-6feb2-default-rtdb.asia-southeast1.firebasedatabase.app/db.json').then((res) => res.json()
        ).then((data) => {
            const array = category ? data.filter((item) => item[category] === value) : data
            localStorage.setItem('goods', JSON.stringify(array))

            if (window.location.pathname !== '/goods.html') {
                window.location.href = '/goods.html' //делается для избавления от постоянного открытия одной и той же страницы в случае если мы уже на ней
            } else { renderGoods(array) }

        })
    }/*по любому переходит аргумент из прошлого then так что это просто переменная*/


    links.forEach((link) => {
        link.addEventListener('click', (event) => {
            event.preventDefault() /*удаляет попытки открыть ссылку и засорять ссылку дефолтной затычкой с хрефа*/
            const value = link.textContent
            const category = link.dataset.field
            console.log(category);
            GetData(category, value)
        })

    })

    Viewall.addEventListener('click', (event) => {
        event.preventDefault()
        const a = undefined;
        const value = Viewall.textContent
        GetData(a, value) 
    }
    

    )




    if (localStorage.getItem('goods') && window.location.pathname === '/goods.html') {
        renderGoods(JSON.parse(localStorage.getItem('goods'))) //в локалсторидж хранится только текст поэтому переводим в формат JSON
    }
    // localStorage.setItem('goods', JSON.stringify([1, 2, 3, 4, 5]))
    // const goods = JSON.parse(localStorage.getItem('goods'))
    // console.log(localStorage);
    //console.log(localStorage);

}

GetGoods()